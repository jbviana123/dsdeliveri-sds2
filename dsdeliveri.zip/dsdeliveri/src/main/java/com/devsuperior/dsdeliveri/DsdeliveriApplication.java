package com.devsuperior.dsdeliveri;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsdeliveriApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsdeliveriApplication.class, args);
	}

}
